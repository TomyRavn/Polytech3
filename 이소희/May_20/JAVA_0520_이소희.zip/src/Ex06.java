
public class Ex06 {
	public static void main(String[] args) {
		// for을 이용하여 '*****'를 다섯 행 출력하기
	
		
		for(int j =1; j<=5; j++) {
			for(int i =1; i<=5; i++)
			System.out.print("*");
			System.out.println();
		}
	}
}
