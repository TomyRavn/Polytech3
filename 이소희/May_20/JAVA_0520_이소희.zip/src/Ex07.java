
public class Ex07 {
	public static void main(String[] args) {
	
		
/*행 제어*/	for(int j =1; j<=5; j++) {
/*열 제어*/	 	for(int i =1; i<=5; i++)
				System.out.printf("(%d,%d)\n", j,i);
				System.out.println();
		}
	}
}
