
public class Ex08 {
	public static void main(String[] args) {
//	 	'*'
//		'**'
//		'***'
//		'****'
//		'*****' 출력하기

	
		
	for(int j =1; j<=5; j++) {
	 	for(int i = 1; i <= j; i++)
	 		System.out.print("*");

				System.out.println();
		}
	}
}
