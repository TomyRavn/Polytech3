
public class Ex03 {

	public static void main(String[] args) {
		int x = 20;
		int y = 50;
		int max;
		
		//조건식? True_value1: False_value2; 조건이 참이면 value1 값, 거짓이면 value2값 출력 
		max = x>y? x:y;
		System.out.printf("최댓값: %d\n", max);

	}

}
