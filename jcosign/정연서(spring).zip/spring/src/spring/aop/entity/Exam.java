package spring.aop.entity;

public interface Exam {
	int total();
	float avg();
}