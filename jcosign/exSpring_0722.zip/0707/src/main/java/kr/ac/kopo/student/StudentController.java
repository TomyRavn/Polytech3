package kr.ac.kopo.student;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class StudentController {
	// @Autowired,@Inject,@Resource 중 하나를 사용하여 스프링에 등록된 객체를 주입
	
	@Resource(name = "studentService")
	private StudentService studentService = new StudentServiceImpl();

	@RequestMapping(value = "/student/list.do", method = RequestMethod.GET)
	public String list(Map modelMap) {
		List<StudentVo> list = studentService.selectStudentList();
		modelMap.put("stuList", list);
		
		return "student/stuList";
	}

	@RequestMapping(value = "/student/add.do", method = RequestMethod.GET)
	public String addform() {
		return "student/stuAddForm";
	}

	@RequestMapping(value = "/student/add.do", method = RequestMethod.POST)
	public String add(StudentVo vo, HttpSession session) {

		
		int num = studentService.insertStudent(vo);
		return "redirect:/student/list.do";
	}

	@RequestMapping(value = "/student/edit.do", method = RequestMethod.GET)
	public String editform(String stuNo, Map modelMap) {
		StudentVo vo = studentService.selectStudent(stuNo);
		modelMap.put("stuVo", vo);
		return "student/stuEditForm";
	}

	@RequestMapping(value = "/student/edit.do", method = RequestMethod.POST)
	public String edit(StudentVo vo) {

		int num = studentService.updateStudentVo(vo);
		System.out.println(num + "개의 레코드 변경");
		return "redirect:/student/list.do";

	}

	@RequestMapping(value = "/student/del.do")
	public String delStudent(String stuNo) {
		int num = studentService.delStudent(stuNo);
		System.out.println(num + "명의 회원삭제");
		return "redirect:/student/list.do";
	}
}
