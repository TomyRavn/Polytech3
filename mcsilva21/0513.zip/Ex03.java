
public class Ex03 {

	public static void main(String[] args) {
		
			int x = 20;
			int y = 50;
			int max;
			
	        // ���ǽ� ? True_value:False_value;	
			
			max = (x>y)?  x: y;
			
			System.out.printf("�ִ밪:%d\n", max);
			
	}

}
