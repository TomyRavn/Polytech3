package Calc;

public class Add extends Calc{
	
	@Override
	int calculate() {
		return a + b;
	}
	
}