package Calc;

public class Mul extends Calc{

	@Override
	int calculate() {
		return a * b;
	}
	
}