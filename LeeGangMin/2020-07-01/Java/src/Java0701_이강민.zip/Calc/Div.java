package Calc;

public class Div extends Calc{

	@Override
	int calculate() {
		return a / b;
	}
	
}