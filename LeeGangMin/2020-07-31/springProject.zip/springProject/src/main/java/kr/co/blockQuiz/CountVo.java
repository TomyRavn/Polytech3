package kr.co.blockQuiz;

public class CountVo {
	private int corCount;
	private int errCount;
	private int totCount;
	
	
	public int getCorCount() {
		return corCount;
	}
	public void setCorCount(int corCount) {
		this.corCount = corCount;
	}
	public int getErrCount() {
		return errCount;
	}
	public void setErrCount(int errCount) {
		this.errCount = errCount;
	}
	public int getTotCount() {
		return totCount;
	}
	public void setTotCount(int totCount) {
		this.totCount = totCount;
	}
		
}