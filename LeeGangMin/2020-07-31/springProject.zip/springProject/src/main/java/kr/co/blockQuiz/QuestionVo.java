package kr.co.blockQuiz;

public class QuestionVo {
	
	private String questionWord;
	private String questionExplain;
	private String questionWriter;
	
	
	public String getQuestionWord() {
		return questionWord;
	}
	public void setQuestionWord(String questionWord) {
		this.questionWord = questionWord;
	}
	public String getQuestionExplain() {
		return questionExplain;
	}
	public void setQuestionExplain(String questionExplain) {
		this.questionExplain = questionExplain;
	}
	public String getQuestionWriter() {
		return questionWriter;
	}
	public void setQuestionWriter(String questionWriter) {
		this.questionWriter = questionWriter;
	}

}