package spring.di.ui;

import spring.di.entity.Exam;

public interface ExamConsole {
	void print();
	void setExam(Exam exam);
}