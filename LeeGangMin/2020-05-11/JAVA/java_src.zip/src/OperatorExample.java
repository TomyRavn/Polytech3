//import Manager.OPERATOR_MANAGER;

public class OperatorExample {
	public static void main(String[] args) {
		int result, a, b;
		
		a = 100;
		b = 50;
		
		result = a + b;
		System.out.println(a + "+" + b + "=" + result);
		
		result = a - b;
		System.out.println(a + "-" + b + "=" + result);
		
		result = a * b;
		System.out.println(a + "*" + b + "=" + result);
		
		result = a / b;
		System.out.println(a + "/" + b + "=" + result);
		
		//OPERATOR_MANAGER.getInstance().addprint(a, b);
	}
}