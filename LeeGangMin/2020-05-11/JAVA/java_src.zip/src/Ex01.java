//���������� �������� Ex01

public class Ex01 {
	public static void main(String[] args) {
		int var1;
		
		if(true) {
			int var2;
			
			var1 = 10;
			var2 = 20;
		}
		int var2;
		var1 = 10;
		var2 = 25;
		
		for(int i = 0; i < 1; i++) {
			int var3;
			
			var1 = 10;
			var3 = 30;
		}
		int var3;
		var1 = 10;
		var3 = 35;
		
		System.out.println(var1);
		System.out.println(var2);
		System.out.println(var3);
	}
}