package Test;

import Manager.OPERATOR_MANAGER;

public class ExTest {

	public static void main(String[] args) {
		
		int a = 5;
		int b = 10;

		OPERATOR_MANAGER.getInstance().addprint(a, b);
	}
}