public class Ex04 {
	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		/*a.*/
		System.out.println(a > b);
		/*b.*/
		System.out.printf("%s\n", a>b);
		/*c.*/
		boolean result = a > b;
		System.out.printf("%s\n", result);
	}
}