import java.util.Scanner;

public class ScannerExample {
	public static void main(String[] args) {
		int a, b, result;
		
		Scanner s = new Scanner(System.in);
		System.out.print("1��° ���� �Է��ϼ��� > ");
		a = s.nextInt();
		System.out.print("2��° ���� �Է��ϼ��� > ");
		b = s.nextInt();
		
		result = a + b;
		System.out.println(a + "+" + b + "=" + result);
		
		result = a - b;
		System.out.println(a + "-" + b + "=" + result);
		
		result = a * b;
		System.out.println(a + "*" + b + "=" + result);
		
		result = a / b;
		System.out.println(a + "/" + b + "=" + result);
	}
}